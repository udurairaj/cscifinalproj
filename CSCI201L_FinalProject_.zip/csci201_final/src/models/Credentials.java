package models;

public class Credentials {
	public static String user = "root";
	public static String pwd = "root";
}
