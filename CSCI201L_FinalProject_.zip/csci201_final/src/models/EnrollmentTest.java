package models;

public class EnrollmentTest {
	public static void main(String[] args) 
	{
//		Instructor i = new Instructor("IJay Lin", "j@gmail.com", 123);
////		Instructor i2 = new Instructor("JayDupe Lin", "j", "login123");
//		Instructor i3 = new Instructor("JayDupe Lin2", "j2", "login1234");
//		i.createNewClass("CSCI201L");
//		Class c = i.getClasses().get(0);
//		System.out.println(c.getClassCode());
		
//		Student s = new Student("SJay Lin", "j2@gmail.com", "login");
//		s2.enrollClass("FuZDqg");
//		Class c = s.getClasses().get(0);
//		System.out.println(c.getClassCode());
		
//		Student s = DatabaseUtil.getStudent("login2");
//		if(s != null)
//		{
//			Class c = s.getClasses().get(0);
//			System.out.println(c.getClassCode());
//		}
//		else
//		{
//			System.out.println("STUDENT DNE");
//		}
	}
}
